# Учебный комплект S01 к книге «ИИ для малого бизнеса: автоматизация повседневных процессов»

Автор: Мозес Горкин, 2026. Учебный комплект S01, версия 1.1 (код версии 1.0 без изменений).

Synthetic Equipment Service — вымышленная сервисная компания США с восемью сотрудниками. Все входные данные синтетические. Пример соответствует CH04 и демонстрирует локальную обработку заявки, SQLite, повторы и ручное согласование. Ответы анализатора заранее подготовлены: модель и внешние сервисы не вызываются.

Для первого знакомства откройте [краткое руководство](../../00_НАЧНИТЕ_СЮДА.txt) в корне комплекта.

## Требования и запуск

Распакуйте ZIP в отдельную папку. Откройте PowerShell в корне распаковки, где находится каталог examples. Нужен установленный Python3.10+ с sqlite3 из стандартной библиотеки; дополнительные пакеты и ключи не нужны. Команда python должна выбирать этот интерпретатор; иначе задайте полный путь в $s01Python. Создаётся новый уникальный outputs-каталог, существующие результаты не удаляются.

```powershell
$s01Python = 'python' # Или полный путь к установленному python.exe версии 3.10+
$s01 = 'examples/S01_lead_to_crm'
$s01Output = Join-Path "$s01/outputs" ([guid]::NewGuid().ToString('N'))
& $s01Python -B -m unittest discover -s "$s01/tests" -p test_s01.py -v
if ($LASTEXITCODE -ne 0) { throw 'S01 tests failed' }
& $s01Python -B "$s01/src/s01.py" --output-dir $s01Output run
if ($LASTEXITCODE -ne 0) { throw 'S01 run failed' }
$run = Get-Content -LiteralPath "$s01Output/results.json" -Raw | ConvertFrom-Json
$run.results | Group-Object status | Select-Object Name, Count
$run.results | Where-Object request_id -eq 'S01-REQ-001' | Format-List
```

На новой базе:14 событий,3 ACCEPTED /1 DUPLICATE /3 NEEDS_INFO /6 REJECTED /1 CONFLICT;2контакта и3обращения. Все3черновика — PENDING_REVIEW. Полный эталон: [expected/batch.json](expected/batch.json). Для001 видны ACCEPTED, DUPLICATE и CONFLICT: исходная запись не перезаписывается. **Не согласовывайте001 до разрешения конфликта.** Код approve сам не выполняет такую проверку; это обязательная ручная граница учебного примера.

## Прочитать и согласовать только неконфликтную002

Сначала убедитесь, что для002 в первом $run один исход ACCEPTED / LINKED / PENDING_REVIEW. Прочитайте исходное сообщение в input/requests.json и черновик из SQLite в режиме только чтения:

```powershell
@'
import json, sqlite3, sys
from pathlib import Path
from contextlib import closing
root, output = map(Path, sys.argv[1:])
rows = json.loads((root / "input/requests.json").read_text(encoding="utf-8"))
print(next(r for r in rows if r["request_id"] == "S01-REQ-002"))
with closing(sqlite3.connect((output / "crm.sqlite3").resolve().as_uri() + "?mode=ro", uri=True)) as db:
    print(db.execute("SELECT email, topic, draft_status, draft FROM requests WHERE request_id = ?", ("S01-REQ-002",)).fetchone())
'@ | & $s01Python -B - $s01 $s01Output
if ($LASTEXITCODE -ne 0) { throw 'Could not read the draft' }
```

002 — MAINTENANCE, клиент client.one@example.com, запрос планового обслуживания учебного компрессора. Черновик просит модель оборудования и историю обслуживания; цены, срока и отправки нет. Если данные отличаются, остановитесь. После проверки смоделируйте решение сотрудника и повтор:

```powershell
& $s01Python -B "$s01/src/s01.py" --output-dir $s01Output approve --request-id S01-REQ-002 --reviewer SYN-REVIEWER-001 --confirm
if ($LASTEXITCODE -ne 0) { throw 'S01 approval failed' }
& $s01Python -B "$s01/src/s01.py" --output-dir $s01Output approve --request-id S01-REQ-002 --reviewer SYN-REVIEWER-002 --confirm
if ($LASTEXITCODE -ne 0) { throw 'S01 repeat approval failed' }
& $s01Python -B "$s01/src/s01.py" --output-dir $s01Output run
if ($LASTEXITCODE -ne 0) { throw 'S01 replay failed' }
```

Первый approve возвращает APPROVED; повтор — ALREADY_APPROVED, первый reviewer сохраняется. Повтор run:4 DUPLICATE /3 NEEDS_INFO /6 REJECTED /1 CONFLICT;2контакта/3обращения.002 остаётся APPROVED;001 и011 — PENDING_REVIEW. Учебный reviewer не удостоверяет личность сотрудника. Согласование не отправляет письмо.

## Состав и доказательность

src/s01.py и src/analysis_stub.py — неизменённый локальный код; input/ —14событий, подготовленные ответы и полный текст запроса для отдельного будущего испытания. Невалидные адреса/даты, вредоносная команда и запрещённое обещание цены — намеренные отрицательные фикстуры. Промпт в T0 не исполняется моделью. expected/ — исходный эталон; tests/test_s01.py —15существующих тестов. Изолированные тесты используют001 без конфликтующего события; это не инструкция согласовывать конфликтующую001 после полного пакета.

Контрольные ожидания и порядок воспроизведения — [REPRODUCIBILITY_REPORT.md](REPRODUCIBILITY_REPORT.md). Исторический TEST_REPORT не включён, чтобы не воспроизводить устаревшее согласование001. MANIFEST_SHA256.txt в корне ZIP покрывает каждый вложенный файл кроме себя; внешняя SHA sidecar проверяет ZIP целиком.

T0 проверяет только локальную логику и заготовки. T1/T2/T3 — NOT_RUN; внешние действия — LIVE_NOT_TESTED. HubSpot/Gmail/Make и настоящая модель не проверены. Условия использования кода, документации и данных приведены в [LICENSE_SCOPE.md](LICENSE_SCOPE.md).

## Контроль целостности и область лицензий

В папке с полученным ZIP сравните внешний sidecar с результатом `Get-FileHash -LiteralPath '.\BOOK04_S01_READER_RELEASE_2026_1_1.zip' -Algorithm SHA256`. Sidecar содержит SHA всего ZIP; внутри архива этот SHA не дублируется во избежание самоссылки.

После распаковки MANIFEST_SHA256.txt находится над examples. Каждая строка: SHA-256, два пробела и относительный POSIX-путь. Для каждого файла, перечисленного в манифесте вычислите SHA; например, в корне распаковки `Get-FileHash -LiteralPath '.\examples\S01_lead_to_crm\src\s01.py' -Algorithm SHA256`. Сверьте все строки и отсутствие лишних файлов до первого запуска. Manifest не хеширует сам себя. Не запускайте неизвестный или несовпавший комплект.

Код и тесты распространяются по лицензии MIT; документация, учебный промпт и синтетические данные — по CC BY 4.0. Область лицензий: [LICENSE_SCOPE.md](LICENSE_SCOPE.md). Издание книги, её обложка и сайт в эту область не входят.

Комплект демонстрационный, не готовое промышленное решение. Перед применением в своей организации самостоятельно проверьте и адаптируйте правила обработки, доступ, безопасность, правовые требования и устойчивость к сбоям. Не используйте реальные персональные данные при выполнении данного упражнения. Результаты работы внешних сервисов и экономический эффект не гарантируются.
