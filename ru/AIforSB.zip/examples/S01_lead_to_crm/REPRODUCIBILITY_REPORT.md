# Воспроизводимость учебного комплекта S01, версия 1.0

Мозес Горкин, 2026. Ниже приведены ожидаемые результаты проверки на чистой базе.

| Контроль после чистой распаковки | Ожидание |
| --- | --- |
| python -B -m unittest discover -s examples/S01_lead_to_crm/tests -p test_s01.py -v | 15/15, exit 0 |
| Первый run на пустой SQLite | 14 событий; ACCEPTED 3 / DUPLICATE 1 / NEEDS_INFO 3 / REJECTED 6 / CONFLICT 1; 2 contacts / 3 requests |
| Первый results.json | Полное равенство expected/batch.json, все три черновика PENDING_REVIEW |
| До согласования | Прочитать исходную 002 и SQLite mode=ro: MAINTENANCE / client.one@example.com / PENDING_REVIEW |
| approve 002, затем другой reviewer | APPROVED / ALREADY_APPROVED; первый SYN-REVIEWER-001 сохранён |
| Повтор run | DUPLICATE 4 / NEEDS_INFO 3 / REJECTED 6 / CONFLICT 1; 2 contacts / 3 requests |
| Черновики после повтора | 002 APPROVED, 001 и 011 PENDING_REVIEW |
| SQLite | integrity_check: ok; foreign_key_check: 0 нарушений |
| Windows PowerShell 5.1 | Исполнить все три блока README в одной сессии |

001 в полном пакете конфликтует; не согласовывать её без разрешения конфликта. approve не проверяет конфликт автоматически: ручная проверка — обязательная граница примера. Тесты, использующие изолированную 001 без конфликтующего события, не являются инструкцией approve конфликтующей 001 после полного run.

Только синтетические данные и T0. Ответы анализатора подготовлены заранее; настоящая модель, CRM, SMTP/HTTP, отправка писем и платные сервисы не используются. T1/T2/T3 — NOT_RUN; внешние действия — LIVE_NOT_TESTED. Учебный reviewer не удостоверяет личность. Технические испытания не подтверждают готовность к промышленной эксплуатации.
