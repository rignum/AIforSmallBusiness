"""Contract and scripted responses for the offline analysis boundary."""

from dataclasses import dataclass


SAFE_DRAFTS = {
    "REPAIR": "Thank you for your repair request. Please share the equipment model and describe the fault.",
    "MAINTENANCE": "Thank you for your maintenance request. Please share the equipment model and its maintenance history.",
    "INSPECTION": "Thank you for your inspection request. Please share the equipment model and what you would like us to inspect.",
}


@dataclass(frozen=True)
class AnalysisInput:
    request_id: str
    message: str


class ScriptedAnalysis:
    """Look up a prepared response by ID without interpreting the message."""

    def __init__(self, responses: dict[str, object]):
        self.responses = responses

    def __call__(self, request: AnalysisInput) -> object:
        return self.responses.get(request.request_id)


@dataclass(frozen=True)
class AnalysisResult:
    topic: str
    draft: str | None


def validate_analysis(output: object) -> AnalysisResult:
    if not isinstance(output, dict) or set(output) != {"topic", "draft"}:
        raise ValueError("scripted analysis must contain only topic and draft")
    topic, draft = output["topic"], output["draft"]
    if topic == "CLARIFICATION" and draft is None:
        return AnalysisResult(topic, None)
    if not isinstance(topic, str) or topic not in SAFE_DRAFTS:
        raise ValueError("scripted analysis has an unsupported topic")
    if draft != SAFE_DRAFTS[topic]:
        raise ValueError("scripted draft does not match the safe wording")
    return AnalysisResult(topic, draft)
