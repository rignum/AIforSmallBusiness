"""S01 T0 demo using a local SQLite CRM simulation."""

import argparse
from collections.abc import Callable
from contextlib import closing
from dataclasses import asdict, dataclass
from datetime import datetime
import hashlib
import json
from pathlib import Path
import re
import sqlite3
import sys

from analysis_stub import AnalysisInput, ScriptedAnalysis, validate_analysis


ROOT = Path(__file__).resolve().parents[1]
REQUEST_ID = re.compile(r"S01-REQ-[0-9]{3}")
REVIEWER_ID = re.compile(r"SYN-REVIEWER-[0-9]{3}")
EXAMPLE_EMAIL = re.compile(
    r"[a-z0-9_+%-]+(?:\.[a-z0-9_+%-]+)*@example\.(?:com|org|net)", re.ASCII
)
UTC_TIMESTAMP = re.compile(r"[0-9]{4}-[0-9]{2}-[0-9]{2}T[0-9]{2}:[0-9]{2}:[0-9]{2}Z")
SCHEMA = """
CREATE TABLE IF NOT EXISTS contacts (
    email TEXT PRIMARY KEY,
    name TEXT NOT NULL
);
CREATE TABLE IF NOT EXISTS requests (
    request_id TEXT PRIMARY KEY,
    email TEXT NOT NULL REFERENCES contacts(email),
    channel TEXT NOT NULL,
    received_at TEXT NOT NULL,
    fingerprint TEXT NOT NULL,
    topic TEXT NOT NULL,
    draft TEXT NOT NULL,
    draft_status TEXT NOT NULL DEFAULT 'PENDING_REVIEW',
    reviewed_by TEXT,
    CHECK (
        (draft_status = 'PENDING_REVIEW' AND reviewed_by IS NULL)
        OR (draft_status = 'APPROVED' AND reviewed_by IS NOT NULL)
    )
);
"""


@dataclass(frozen=True)
class Request:
    request_id: str
    channel: str
    received_at: str
    name: str
    email: str
    message: str

    def fingerprint(self) -> str:
        payload = json.dumps(asdict(self), sort_keys=True)
        return hashlib.sha256(payload.encode("ascii")).hexdigest()


@dataclass(frozen=True)
class Result:
    request_id: str | None
    status: str
    contact: str = "NONE"
    draft_status: str | None = None
    error: str | None = None


class MissingField(ValueError):
    pass


def required_text(row: dict, field: str, limit: int) -> str:
    value = row.get(field)
    if value is None or (isinstance(value, str) and not value.strip()):
        raise MissingField(f"{field} is required")
    if not isinstance(value, str) or len(value.strip()) > limit or "\0" in value:
        raise ValueError(f"{field} must be text of at most {limit} characters")
    value = value.strip()
    try:
        value.encode("utf-8")
    except UnicodeEncodeError:
        raise ValueError(f"{field} must be valid Unicode text") from None
    return value


def normalize(row: dict, request_id: str) -> Request:
    channel = required_text(row, "channel", 20)
    if channel != "web_form":
        raise ValueError("channel must be web_form")
    date = required_text(row, "received_at", 20)
    try:
        if not UTC_TIMESTAMP.fullmatch(date):
            raise ValueError
        datetime.strptime(date, "%Y-%m-%dT%H:%M:%SZ")
    except ValueError:
        raise ValueError("received_at must be a valid UTC timestamp") from None
    name = " ".join(required_text(row, "name", 120).split())
    email = required_text(row, "email", 254).lower()
    if not EXAMPLE_EMAIL.fullmatch(email) or len(email.split("@")[0]) > 64:
        raise ValueError("email must use a valid address at an example domain")
    message = required_text(row, "message", 2000).replace("\r\n", "\n").replace("\r", "\n")
    return Request(request_id, channel, date, name, email, message)


class LocalCRM:
    def __init__(self, connection: sqlite3.Connection):
        self.db = connection
        self.db.row_factory = sqlite3.Row
        self.db.execute("PRAGMA foreign_keys = ON")
        self.db.executescript(SCHEMA)

    def counts(self) -> dict[str, int]:
        return {
            "contacts": self.db.execute("SELECT COUNT(*) FROM contacts").fetchone()[0],
            "requests": self.db.execute("SELECT COUNT(*) FROM requests").fetchone()[0],
        }

    def process(self, row: object, analyze: Callable[[AnalysisInput], object]) -> Result:
        if not isinstance(row, dict):
            return Result(None, "REJECTED", error="request must be a JSON object")
        raw_id = row.get("request_id")
        if not isinstance(raw_id, str) or not REQUEST_ID.fullmatch(raw_id.strip()):
            return Result(None, "REJECTED", error="request_id must match S01-REQ-NNN")
        request_id = raw_id.strip()
        try:
            request = normalize(row, request_id)
        except MissingField as exc:
            return Result(request_id, "NEEDS_INFO", error=str(exc))
        except ValueError as exc:
            return Result(request_id, "REJECTED", error=str(exc))

        fingerprint = request.fingerprint()
        try:
            with self.db:
                self.db.execute("BEGIN IMMEDIATE")
                existing = self.db.execute(
                    "SELECT fingerprint, draft_status FROM requests WHERE request_id = ?",
                    (request_id,),
                ).fetchone()
                if existing:
                    if existing["fingerprint"] != fingerprint:
                        return Result(request_id, "CONFLICT", error="request_id already identifies different data")
                    return Result(request_id, "DUPLICATE", "UNCHANGED", existing["draft_status"])

                try:
                    analysis = validate_analysis(analyze(AnalysisInput(request_id, request.message)))
                except ValueError as exc:
                    return Result(request_id, "REJECTED", error=str(exc))
                if analysis.draft is None:
                    return Result(request_id, "NEEDS_INFO", error="request topic requires clarification")

                contact = self.db.execute(
                    "INSERT INTO contacts (email, name) VALUES (?, ?) ON CONFLICT(email) DO NOTHING",
                    (request.email, request.name),
                )
                self.db.execute(
                    """INSERT INTO requests
                       (request_id, email, channel, received_at, fingerprint, topic, draft)
                       VALUES (?, ?, ?, ?, ?, ?, ?)""",
                    (request_id, request.email, request.channel, request.received_at,
                     fingerprint, analysis.topic, analysis.draft),
                )
                action = "CREATED" if contact.rowcount == 1 else "LINKED"
                return Result(request_id, "ACCEPTED", action, "PENDING_REVIEW")
        except sqlite3.Error:
            return Result(request_id, "RETRYABLE_ERROR", error="local storage failed; fix storage and retry")

    def approve(self, request_id: str, reviewer: str) -> str:
        if not REQUEST_ID.fullmatch(request_id):
            raise ValueError("request_id must match S01-REQ-NNN")
        if not REVIEWER_ID.fullmatch(reviewer):
            raise ValueError("reviewer must match SYN-REVIEWER-NNN")
        with self.db:
            cursor = self.db.execute(
                """UPDATE requests SET draft_status = 'APPROVED', reviewed_by = ?
                   WHERE request_id = ? AND draft_status = 'PENDING_REVIEW'""",
                (reviewer, request_id),
            )
            if cursor.rowcount == 1:
                return "APPROVED"
            existing = self.db.execute(
                "SELECT draft_status FROM requests WHERE request_id = ?", (request_id,)
            ).fetchone()
            if existing is None:
                raise ValueError("request does not have a stored draft")
            return "ALREADY_APPROVED"


def run_batch(crm: LocalCRM, rows: list, analyze: ScriptedAnalysis) -> dict:
    results = [asdict(crm.process(row, analyze)) for row in rows]
    return {**crm.counts(), "results": results}


def read_json(path: Path) -> object:
    return json.loads(path.read_text(encoding="utf-8"))


def main(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--output-dir", type=Path, default=ROOT / "outputs")
    commands = parser.add_subparsers(dest="command", required=True)
    commands.add_parser("run", help="process the synthetic batch with scripted analysis")
    approval = commands.add_parser("approve", help="explicitly approve a stored draft locally")
    approval.add_argument("--request-id", required=True)
    approval.add_argument("--reviewer", required=True)
    approval.add_argument("--confirm", action="store_true", required=True)
    args = parser.parse_args(argv)

    output = args.output_dir.resolve()
    database = output / "crm.sqlite3"
    try:
        if args.command == "approve":
            with closing(sqlite3.connect(database.as_uri() + "?mode=rw", uri=True)) as connection:
                status = LocalCRM(connection).approve(args.request_id, args.reviewer)
            print(json.dumps({"request_id": args.request_id, "status": status}))
            return 0

        rows = read_json(ROOT / "input" / "requests.json")
        responses = read_json(ROOT / "input" / "scripted_analysis.json")
        if not isinstance(rows, list) or not isinstance(responses, dict):
            raise ValueError("batch must be a list and scripted responses must be an object")
        output.mkdir(parents=True, exist_ok=True)
        with closing(sqlite3.connect(database)) as connection:
            report = run_batch(LocalCRM(connection), rows, ScriptedAnalysis(responses))
        result_path = output / "results.json"
        result_path.write_text(json.dumps(report, indent=2) + "\n", encoding="utf-8")
        print(f"{len(rows)} rows; {report['contacts']} contacts; {report['requests']} requests; {result_path}")
        return int(any(row["status"] == "RETRYABLE_ERROR" for row in report["results"]))
    except ValueError as exc:
        print(f"S01: {exc}", file=sys.stderr)
        return 1
    except (OSError, sqlite3.Error):
        print("S01: local file or storage operation failed", file=sys.stderr)
        return 1


if __name__ == "__main__":
    raise SystemExit(main())
