import contextlib
from dataclasses import asdict, replace
import io
from pathlib import Path
import sqlite3
import sys
import tempfile
import unittest

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / "src"))

from analysis_stub import AnalysisInput, SAFE_DRAFTS, ScriptedAnalysis
from s01 import LocalCRM, Result, main, read_json, run_batch


ROWS = read_json(ROOT / "input" / "requests.json")
RESPONSES = read_json(ROOT / "input" / "scripted_analysis.json")


class PilotTests(unittest.TestCase):
    def setUp(self):
        self.db = sqlite3.connect(":memory:")
        self.addCleanup(self.db.close)
        self.crm = LocalCRM(self.db)
        self.analyze = ScriptedAnalysis(RESPONSES)

    def process(self, index: int) -> Result:
        return self.crm.process(ROWS[index], self.analyze)

    def assert_counts(self, contacts: int, requests: int):
        self.assertEqual(self.crm.counts(), {"contacts": contacts, "requests": requests})

    def assert_no_draft(self, result: Result, status: str):
        self.assertEqual(result.status, status)
        self.assertEqual(result.contact, "NONE")
        self.assertIsNone(result.draft_status)
        self.assertTrue(result.error)
        self.assert_counts(0, 0)

    def test_TC01_new_request(self):
        result = self.process(0)
        self.assertEqual(result, Result("S01-REQ-001", "ACCEPTED", "CREATED", "PENDING_REVIEW"))
        self.assert_counts(1, 1)
        stored = self.db.execute(
            """SELECT contacts.name, requests.email, requests.topic, requests.draft
               FROM requests JOIN contacts USING (email)"""
        ).fetchone()
        self.assertEqual(
            tuple(stored),
            ("Synthetic Client One", "client.one@example.com", "REPAIR", SAFE_DRAFTS["REPAIR"]),
        )

    def test_TC02_retry_same_id(self):
        first = self.process(0)

        def must_not_call(_request):
            self.fail("A duplicate reached the analysis component")

        duplicate = self.crm.process(ROWS[1], must_not_call)
        self.assertEqual(duplicate, replace(first, status="DUPLICATE", contact="UNCHANGED"))
        self.assert_counts(1, 1)

    def test_TC03_reuse_contact(self):
        self.process(0)
        self.assertEqual(self.process(2), Result("S01-REQ-002", "ACCEPTED", "LINKED", "PENDING_REVIEW"))
        self.assert_counts(1, 2)
        self.assertEqual(self.db.execute("SELECT COUNT(DISTINCT email) FROM requests").fetchone()[0], 1)

    def test_TC04_missing_required_field(self):
        self.assert_no_draft(self.process(3), "NEEDS_INFO")
        for field in ("channel", "received_at", "name", "message"):
            with self.subTest(field=field):
                row = dict(ROWS[0])
                del row[field]
                self.assert_no_draft(self.crm.process(row, self.analyze), "NEEDS_INFO")

    def test_TC05_bad_email_or_date(self):
        for index in (4, 5):
            with self.subTest(index=index):
                self.assert_no_draft(self.process(index), "REJECTED")
        for field, value in (
            ("email", "client@example.invalid"),
            ("email", "client..one@example.com"),
            ("received_at", "2026-11-07T09:00:00+00:00"),
        ):
            with self.subTest(field=field, value=value):
                self.assert_no_draft(self.crm.process({**ROWS[0], field: value}, self.analyze), "REJECTED")

    def test_TC06_blank_or_vague_request(self):
        for index in (6, 7):
            with self.subTest(index=index):
                self.assert_no_draft(self.process(index), "NEEDS_INFO")

    def test_TC07_invalid_analysis(self):
        self.assert_no_draft(self.process(8), "REJECTED")
        for output in (None, [], {"topic": "REPAIR"}, {"topic": ["REPAIR"], "draft": None}):
            with self.subTest(output=output):
                self.assert_no_draft(self.crm.process(ROWS[0], lambda _: output), "REJECTED")

    def test_TC08_unsupported_promise(self):
        self.assert_no_draft(self.process(9), "REJECTED")
        for draft in ("It costs USD 50.", "We will finish by tomorrow.", "We guarantee success."):
            with self.subTest(draft=draft):
                response = {"topic": "REPAIR", "draft": draft}
                self.assert_no_draft(self.crm.process(ROWS[0], lambda _: response), "REJECTED")

    def test_TC09_untrusted_text_and_fake_authority(self):
        result = self.process(10)
        self.assert_no_draft(result, "REJECTED")
        self.assertNotIn(ROWS[10]["message"], str(asdict(result)))

        def prepared_safe_response(request: AnalysisInput):
            self.assertEqual(request.message, ROWS[10]["message"])
            return {"topic": "REPAIR", "draft": SAFE_DRAFTS["REPAIR"]}

        accepted = self.crm.process(ROWS[10], prepared_safe_response)
        self.assertEqual(accepted.draft_status, "PENDING_REVIEW")
        stored = self.db.execute("SELECT draft, reviewed_by FROM requests").fetchone()
        self.assertEqual(tuple(stored), (SAFE_DRAFTS["REPAIR"], None))
        self.assert_counts(1, 1)

    def test_TC10_storage_failure_rolls_back_then_retries(self):
        self.db.executescript(
            """CREATE TRIGGER simulate_failure BEFORE INSERT ON requests
               BEGIN
                   SELECT RAISE(ABORT, 'synthetic storage failure');
               END;"""
        )
        self.assert_no_draft(self.process(0), "RETRYABLE_ERROR")
        self.db.execute("DROP TRIGGER simulate_failure")
        self.assertEqual(self.process(0).status, "ACCEPTED")
        self.assert_counts(1, 1)

    def test_TC11_review_requires_explicit_confirmation(self):
        with tempfile.TemporaryDirectory() as directory:
            db_path = Path(directory) / "crm.sqlite3"
            with contextlib.closing(sqlite3.connect(db_path)) as connection:
                LocalCRM(connection).process(ROWS[0], self.analyze)
            with contextlib.redirect_stderr(io.StringIO()), self.assertRaises(SystemExit) as result:
                main(["--output-dir", directory, "approve", "--request-id", "S01-REQ-001",
                      "--reviewer", "SYN-REVIEWER-001"])
            self.assertEqual(result.exception.code, 2)
            with contextlib.closing(sqlite3.connect(db_path)) as connection:
                self.assertEqual(
                    connection.execute("SELECT draft_status, reviewed_by FROM requests").fetchone(),
                    ("PENDING_REVIEW", None),
                )

    def test_TC12_explicit_approval(self):
        self.process(0)
        with self.assertRaises(ValueError):
            self.crm.approve("S01-REQ-001", "")
        with self.assertRaises(ValueError):
            self.crm.approve("S01-REQ-999", "SYN-REVIEWER-001")
        self.assertEqual(self.crm.approve("S01-REQ-001", "SYN-REVIEWER-001"), "APPROVED")
        self.assertEqual(self.crm.approve("S01-REQ-001", "SYN-REVIEWER-002"), "ALREADY_APPROVED")
        stored = self.db.execute("SELECT draft_status, reviewed_by FROM requests").fetchone()
        self.assertEqual(tuple(stored), ("APPROVED", "SYN-REVIEWER-001"))
        self.assertEqual(self.process(1), Result("S01-REQ-001", "DUPLICATE", "UNCHANGED", "APPROVED"))
        self.assert_counts(1, 1)

    def test_TC13_conflicting_reuse_of_id(self):
        self.process(0)
        before = tuple(self.db.execute("SELECT * FROM requests").fetchone())
        self.assertEqual(self.process(11).status, "CONFLICT")
        self.assertEqual(tuple(self.db.execute("SELECT * FROM requests").fetchone()), before)
        self.assert_counts(1, 1)

    def test_TC14_full_batch_matches_independent_expectations(self):
        expected = read_json(ROOT / "expected" / "batch.json")
        self.assertGreaterEqual(len(ROWS), 12)
        self.assertEqual(run_batch(self.crm, ROWS, self.analyze), expected)

    def test_TC15_invalid_id_or_payload_is_not_recorded(self):
        self.assertIsNone(self.process(13).request_id)
        for row in ([], {"request_id": "raw-untrusted-value"}, {"request_id": 12}):
            with self.subTest(row=row):
                result = self.crm.process(row, self.analyze)
                self.assert_no_draft(result, "REJECTED")
                self.assertIsNone(result.request_id)


if __name__ == "__main__":
    unittest.main()
